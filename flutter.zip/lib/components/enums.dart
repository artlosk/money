
enum ActionsDialog {create, update}

enum TabButton {charges, profile}